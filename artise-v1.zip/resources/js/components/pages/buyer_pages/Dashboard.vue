<template>
   <div class="sb-nav-fixed">
      <Header />
      <div id="layoutSidenav">
         <Sidebar />
         <div id="layoutSidenav_content">
            <DashboardMainContainer />
            <Footer />
         </div>
      </div>
   </div>
</template>
<script>
import Header from "../../widgets/buyer_widgets/Header";
import Sidebar from "../../widgets/buyer_widgets/Sidebar";
import DashboardMainContainer from "../../widgets/buyer_widgets/DashboardMainContainer";
import Footer from "../../widgets/buyer_widgets/Footer";
export default {
   name: "Home",
   components: {
      Header,
      Sidebar,
      DashboardMainContainer,
      Footer,
   },
};
</script>

