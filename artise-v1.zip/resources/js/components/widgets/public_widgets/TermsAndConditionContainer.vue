<template>
  <div id="shopify-section-1585963328748" class="shopify-section velaFramework">
    <div
      class="velaServices mbBlockGutter"
      style="
                            background-color: #f8f8f8;

                            padding: 50px 0;
                        "
    >
      <div class="container">
        <div class="velaServicesInner">
          <div class="velaContent">
            <div class="rowFlex rowFlexMargin">
              <div class="col-xs-12 col-sm-4 mbItemGutter">
                <div class="boxService text-center">
                  <div class="boxServiceImage">
                    <div
                      class="serviceImage"
                      style="width: 48px; height: 48px;"
                    >
                      <div class="p-relative">
                        <div
                          class="product-card__image"
                          style="padding-top: 100%;"
                        >
                          <img
                            class="product-card__img lazyload"
                            data-src="assets/images/truck.png"
                            data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                            data-aspectratio="1.0"
                            data-ratio="1.0"
                            data-sizes="auto"
                            alt=""
                          />
                        </div>
                        <div
                          class="placeholder-background placeholder-background--animation"
                          data-image-placeholder
                        ></div>
                      </div>
                    </div>
                  </div>
                  <div class="boxServiceContent">
                    <h4 class="boxServiceTitle">Fast & Secure shipping</h4>
                    <div class="boxServiceDesc">
                      On all orders.
                    </div>
                    <router-link to="/" title="block.settings.box_text_link"
                      >Learn More<span class="icons icon-arrow-right"></span
                    ></router-link>
                  </div>
                </div>
              </div>

              <div class="col-xs-12 col-sm-4 mbItemGutter">
                <div class="boxService text-center">
                  <div class="boxServiceImage">
                    <div
                      class="serviceImage"
                      style="width: 48px; height: 48px;"
                    >
                      <div class="p-relative">
                        <div
                          class="product-card__image"
                          style="padding-top: 100%;"
                        >
                          <img
                            class="product-card__img lazyload"
                            data-src="assets/images/card.png"
                            data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                            data-aspectratio="1.0"
                            data-ratio="1.0"
                            data-sizes="auto"
                            alt=""
                          />
                        </div>
                        <div
                          class="placeholder-background placeholder-background--animation"
                          data-image-placeholder
                        ></div>
                      </div>
                    </div>
                  </div>
                  <div class="boxServiceContent">
                    <h4 class="boxServiceTitle">100% Payment Secure</h4>
                    <div class="boxServiceDesc">
                      We ensure secure payment with PEV
                    </div>
                    <router-link to="/" title="block.settings.box_text_link"
                      >Learn More<span class="icons icon-arrow-right"></span
                    ></router-link>
                  </div>
                </div>
              </div>

              <div class="col-xs-12 col-sm-4 mbItemGutter">
                <div class="boxService text-center">
                  <div class="boxServiceImage">
                    <div
                      class="serviceImage"
                      style="width: 48px; height: 48px;"
                    >
                      <div class="p-relative">
                        <div
                          class="product-card__image"
                          style="padding-top: 100%;"
                        >
                          <img
                            class="product-card__img lazyload"
                            data-src="assets/images/h.png"
                            data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                            data-aspectratio="1.0"
                            data-ratio="1.0"
                            data-sizes="auto"
                            alt=""
                          />
                        </div>
                        <div
                          class="placeholder-background placeholder-background--animation"
                          data-image-placeholder
                        ></div>
                      </div>
                    </div>
                  </div>
                  <div class="boxServiceContent">
                    <h4 class="boxServiceTitle">7 Days Return</h4>
                    <div class="boxServiceDesc">
                      Return it within 7 days for an exchange or refund
                    </div>
                    <router-link to="/" title="block.settings.box_text_link"
                      >Learn More<span class="icons icon-arrow-right"></span
                    ></router-link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TermsAndConditionContainer",
};
</script>

<style scoped>
.mbBlockGutter {
  margin-bottom: 0px !important;
}
</style>
