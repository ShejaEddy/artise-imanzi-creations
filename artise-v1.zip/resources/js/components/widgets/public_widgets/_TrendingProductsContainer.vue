<template>
    <div
        id="shopify-section-1576654924218"
        class="shopify-section velaFramework"
    >
        <div
            class="productListHome velaProducts mb30"
            style="background-color: rgba(0, 0, 0, 0); padding: 20px 0;"
        >
            <div class="container">
                <div class="headingGroup pb20">
                    <h3 class="velaHomeTitle text-center">
                        Trending Products
                    </h3>
                    <span class="subTitle">Top view in this week</span>
                </div>
                <div class="velaContent">
                    <div class="proOwlCarousel owlCarouselPlay">
                        <div
                            class="owl-carousel"
                            data-nav="true"
                            data-autoplay="false"
                            data-autoplaytimeout="10000"
                            data-columnone="4"
                            data-columntwo="3"
                            data-columnthree="2"
                            data-columnfour="2"
                            data-columnfive="1"
                        >
                            <div class="item">
                                <div
                                    class="velaProBlock grid"
                                    data-price="39,00"
                                >
                                    <div class="velaProBlockInner">
                                        <div
                                            class="proHImage d-flex flexJustifyCenter"
                                        >
                                            <a
                                                class="proFeaturedImage"
                                                href="products/arctander-chair.html"
                                            >
                                                <div class="wrap">
                                                    <div class="p-relative">
                                                        <div
                                                            class="product-card__image"
                                                            style="padding-top: 124.25%;"
                                                        >
                                                            <img
                                                                class="product-card__img lazyload"
                                                                data-src="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/21_1_{width}x.jpg?v=1586317078"
                                                                data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                                                                data-aspectratio="0.8048289738430584"
                                                                data-ratio="0.8048289738430584"
                                                                data-sizes="auto"
                                                                alt=""
                                                            />
                                                        </div>
                                                        <div
                                                            class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder
                                                        ></div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="hidden-sm hidden-xs proSwatch proImageSecond"
                                                >
                                                    <div class="p-relative">
                                                        <div
                                                            class="product-card__image"
                                                            style="padding-top: 124.25%;"
                                                        >
                                                            <img
                                                                class="product-card__img lazyload"
                                                                data-src="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/21_2_{width}x.jpg?v=1598253084"
                                                                data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                                                                data-aspectratio="0.8048289738430584"
                                                                data-ratio="0.8048289738430584"
                                                                data-sizes="auto"
                                                                alt="Arctander Chair"
                                                            />
                                                        </div>
                                                        <div
                                                            class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder
                                                        ></div>
                                                    </div>
                                                </div>
                                            </a>
                                            <div class="productLable"></div>

                                            <div class="proButton clearfix">
                                                <form
                                                    action="https://velademo-Artise.myshopify.com/cart/add"
                                                    method="post"
                                                    enctype="multipart/form-data"
                                                    class="formAddToCart"
                                                >
                                                    <input
                                                        type="hidden"
                                                        name="id"
                                                        value="33475186819116"
                                                    />
                                                    <a
                                                        class="btn btnProduct btnAddToCart"
                                                        href="products/arctander-chair.html"
                                                        title="Select options"
                                                    >
                                                        <span
                                                            class="icons icon-handbag"
                                                        ></span>
                                                        <span
                                                            class="select_options text"
                                                            >Select
                                                            options</span
                                                        >
                                                    </a>
                                                </form>

                                                <div class="productQuickView">
                                                    <a
                                                        class="btn btnProduct btnProductQuickview"
                                                        href="#velaQuickView"
                                                        data-handle="arctander-chair"
                                                        title="Quick view"
                                                    >
                                                        <span
                                                            class="icons icon-magnifier"
                                                        ></span>
                                                        <span class="text"
                                                            >Quick view</span
                                                        >
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="proContent">
                                            <h5 class="proName">
                                                <a
                                                    href="products/arctander-chair.html"
                                                    >Arctander Chair</a
                                                >
                                            </h5>
                                            <div class="groupPrice clearfix">
                                                <div class="proPrice">
                                                    <div class="priceProduct">
                                                        <span class="money"
                                                            >$39,00</span
                                                        >
                                                    </div>
                                                </div>
                                                <div class="velaSwatchCus">
                                                    <ul
                                                        class="velaSwatchProduct"
                                                    >
                                                        <li>
                                                            <label
                                                                style="background-color: yellow; background-image: url(http://cdn.shopify.com/s/files/1/0376/9440/6700/products/21_1_small.jpg?v=1598253084);"
                                                            ></label>
                                                            <div class="hidden">
                                                                <a
                                                                    href="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/21_1_large.jpg?v=1598253084"
                                                                ></a>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <label
                                                                style="
                                                                                background-color: pink;
                                                                                background-image: url(http://cdn.shopify.com/s/files/1/0376/9440/6700/products/2_1_44d927bb-269a-4f5c-be70-61963ee51dd0_small.jpg?v=1598253084);
                                                                            "
                                                            ></label>
                                                            <div class="hidden">
                                                                <a
                                                                    href="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/2_1_44d927bb-269a-4f5c-be70-61963ee51dd0_large.jpg?v=1598253084"
                                                                ></a>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <label
                                                                style="background-color: black; background-image: url(http://cdn.shopify.com/s/files/1/0376/9440/6700/products/18_2_small.jpg?v=1598253084);"
                                                            ></label>
                                                            <div class="hidden">
                                                                <a
                                                                    href="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/18_2_large.jpg?v=1598253084"
                                                                ></a>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <label
                                                                style="
                                                                                background-color: gold;
                                                                                background-image: url(http://cdn.shopify.com/s/files/1/0376/9440/6700/products/2_2_764f9b85-a5ed-415a-8231-214d7e9ac586_small.jpg?v=1598253084);
                                                                            "
                                                            ></label>
                                                            <div class="hidden">
                                                                <a
                                                                    href="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/2_2_764f9b85-a5ed-415a-8231-214d7e9ac586_large.jpg?v=1598253084"
                                                                ></a>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <label
                                                                style="background-color: red; background-image: url(http://cdn.shopify.com/s/files/1/0376/9440/6700/products/21_2_small.jpg?v=1598253084);"
                                                            ></label>
                                                            <div class="hidden">
                                                                <a
                                                                    href="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/21_2_large.jpg?v=1598253084"
                                                                ></a>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div
                                    class="velaProBlock grid"
                                    data-price="39,00"
                                >
                                    <div class="velaProBlockInner">
                                        <div
                                            class="proHImage d-flex flexJustifyCenter"
                                        >
                                            <a
                                                class="proFeaturedImage"
                                                href="products/stainless-steel-teapot.html"
                                            >
                                                <div class="wrap">
                                                    <div class="p-relative">
                                                        <div
                                                            class="product-card__image"
                                                            style="padding-top: 124.25%;"
                                                        >
                                                            <img
                                                                class="product-card__img lazyload"
                                                                data-src="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/28_{width}x.jpg?v=1586316960"
                                                                data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                                                                data-aspectratio="0.8048289738430584"
                                                                data-ratio="0.8048289738430584"
                                                                data-sizes="auto"
                                                                alt=""
                                                            />
                                                        </div>
                                                        <div
                                                            class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder
                                                        ></div>
                                                    </div>
                                                </div>
                                            </a>
                                            <div class="productLable">
                                                <span class="labelSale"
                                                    >Sale</span
                                                >
                                            </div>

                                            <div class="proButton clearfix">
                                                <form
                                                    action="https://velademo-Artise.myshopify.com/cart/add"
                                                    method="post"
                                                    enctype="multipart/form-data"
                                                    class="formAddToCart"
                                                >
                                                    <input
                                                        type="hidden"
                                                        name="id"
                                                        value="33475121676332"
                                                    />
                                                    <button
                                                        class="btn btnProduct btnAddToCart"
                                                        type="submit"
                                                        value="Submit"
                                                        title="Add to Cart"
                                                    >
                                                        <span
                                                            class="icons icon-handbag"
                                                        ></span>
                                                        <span class="text"
                                                            >Add to Cart</span
                                                        >
                                                    </button>
                                                </form>

                                                <div class="productQuickView">
                                                    <a
                                                        class="btn btnProduct btnProductQuickview"
                                                        href="#velaQuickView"
                                                        data-handle="stainless-steel-teapot"
                                                        title="Quick view"
                                                    >
                                                        <span
                                                            class="icons icon-magnifier"
                                                        ></span>
                                                        <span class="text"
                                                            >Quick view</span
                                                        >
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="proContent">
                                            <h5 class="proName">
                                                <a
                                                    href="products/stainless-steel-teapot.html"
                                                    >Stainless steel teapot</a
                                                >
                                            </h5>
                                            <div class="groupPrice clearfix">
                                                <div class="proPrice">
                                                    <div
                                                        class="priceProduct priceCompare"
                                                    >
                                                        <span class="money"
                                                            >$57,00</span
                                                        >
                                                    </div>
                                                    <div
                                                        class="priceProduct priceSale"
                                                    >
                                                        <span class="money"
                                                            >$39,00</span
                                                        >
                                                    </div>
                                                </div>
                                                <div
                                                    class="velaSwatchCus"
                                                ></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div
                                    class="velaProBlock grid"
                                    data-price="39,00"
                                >
                                    <div class="velaProBlockInner">
                                        <div
                                            class="proHImage d-flex flexJustifyCenter"
                                        >
                                            <a
                                                class="proFeaturedImage"
                                                href="products/beoplay-a1.html"
                                            >
                                                <div class="wrap">
                                                    <div class="p-relative">
                                                        <div
                                                            class="product-card__image"
                                                            style="padding-top: 124.25%;"
                                                        >
                                                            <img
                                                                class="product-card__img lazyload"
                                                                data-src="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/29_{width}x.jpg?v=1586316900"
                                                                data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                                                                data-aspectratio="0.8048289738430584"
                                                                data-ratio="0.8048289738430584"
                                                                data-sizes="auto"
                                                                alt=""
                                                            />
                                                        </div>
                                                        <div
                                                            class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder
                                                        ></div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="hidden-sm hidden-xs proSwatch proImageSecond"
                                                >
                                                    <div class="p-relative">
                                                        <div
                                                            class="product-card__image"
                                                            style="padding-top: 124.25%;"
                                                        >
                                                            <img
                                                                class="product-card__img lazyload"
                                                                data-src="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/29_2_{width}x.jpg?v=1586316900"
                                                                data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                                                                data-aspectratio="0.8048289738430584"
                                                                data-ratio="0.8048289738430584"
                                                                data-sizes="auto"
                                                                alt="Beoplay A1"
                                                            />
                                                        </div>
                                                        <div
                                                            class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder
                                                        ></div>
                                                    </div>
                                                </div>
                                            </a>
                                            <div class="productLable">
                                                <span class="labelSale"
                                                    >Sale</span
                                                >
                                            </div>

                                            <div class="proButton clearfix">
                                                <form
                                                    action="https://velademo-Artise.myshopify.com/cart/add"
                                                    method="post"
                                                    enctype="multipart/form-data"
                                                    class="formAddToCart"
                                                >
                                                    <input
                                                        type="hidden"
                                                        name="id"
                                                        value="33475100540972"
                                                    />
                                                    <button
                                                        class="btn btnProduct btnAddToCart"
                                                        type="submit"
                                                        value="Submit"
                                                        title="Add to Cart"
                                                    >
                                                        <span
                                                            class="icons icon-handbag"
                                                        ></span>
                                                        <span class="text"
                                                            >Add to Cart</span
                                                        >
                                                    </button>
                                                </form>

                                                <div class="productQuickView">
                                                    <a
                                                        class="btn btnProduct btnProductQuickview"
                                                        href="#velaQuickView"
                                                        data-handle="beoplay-a1"
                                                        title="Quick view"
                                                    >
                                                        <span
                                                            class="icons icon-magnifier"
                                                        ></span>
                                                        <span class="text"
                                                            >Quick view</span
                                                        >
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="proContent">
                                            <h5 class="proName">
                                                <a
                                                    href="products/beoplay-a1.html"
                                                    >Beoplay A1</a
                                                >
                                            </h5>
                                            <div class="groupPrice clearfix">
                                                <div class="proPrice">
                                                    <div
                                                        class="priceProduct priceCompare"
                                                    >
                                                        <span class="money"
                                                            >$57,00</span
                                                        >
                                                    </div>
                                                    <div
                                                        class="priceProduct priceSale"
                                                    >
                                                        <span class="money"
                                                            >$39,00</span
                                                        >
                                                    </div>
                                                </div>
                                                <div
                                                    class="velaSwatchCus"
                                                ></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div
                                    class="velaProBlock grid lastItem"
                                    data-price="59,00"
                                >
                                    <div class="velaProBlockInner">
                                        <div
                                            class="proHImage d-flex flexJustifyCenter"
                                        >
                                            <a
                                                class="proFeaturedImage"
                                                href="products/turning-table.html"
                                            >
                                                <div class="wrap">
                                                    <div class="p-relative">
                                                        <div
                                                            class="product-card__image"
                                                            style="padding-top: 124.25%;"
                                                        >
                                                            <img
                                                                class="product-card__img lazyload"
                                                                data-src="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/30_{width}x.jpg?v=1586316781"
                                                                data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                                                                data-aspectratio="0.8048289738430584"
                                                                data-ratio="0.8048289738430584"
                                                                data-sizes="auto"
                                                                alt=""
                                                            />
                                                        </div>
                                                        <div
                                                            class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder
                                                        ></div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="hidden-sm hidden-xs proSwatch proImageSecond"
                                                >
                                                    <div class="p-relative">
                                                        <div
                                                            class="product-card__image"
                                                            style="padding-top: 124.25%;"
                                                        >
                                                            <img
                                                                class="product-card__img lazyload"
                                                                data-src="http://cdn.shopify.com/s/files/1/0376/9440/6700/products/30_1_{width}x.jpg?v=1586316781"
                                                                data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]"
                                                                data-aspectratio="0.8048289738430584"
                                                                data-ratio="0.8048289738430584"
                                                                data-sizes="auto"
                                                                alt="Turning Table"
                                                            />
                                                        </div>
                                                        <div
                                                            class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder
                                                        ></div>
                                                    </div>
                                                </div>
                                            </a>
                                            <div class="productLable"></div>

                                            <div class="proButton clearfix">
                                                <form
                                                    action="https://velademo-Artise.myshopify.com/cart/add"
                                                    method="post"
                                                    enctype="multipart/form-data"
                                                    class="formAddToCart"
                                                >
                                                    <input
                                                        type="hidden"
                                                        name="id"
                                                        value="33475052175404"
                                                    />
                                                    <button
                                                        class="btn btnProduct btnAddToCart"
                                                        type="submit"
                                                        value="Submit"
                                                        title="Add to Cart"
                                                    >
                                                        <span
                                                            class="icons icon-handbag"
                                                        ></span>
                                                        <span class="text"
                                                            >Add to Cart</span
                                                        >
                                                    </button>
                                                </form>

                                                <div class="productQuickView">
                                                    <a
                                                        class="btn btnProduct btnProductQuickview"
                                                        href="#velaQuickView"
                                                        data-handle="turning-table"
                                                        title="Quick view"
                                                    >
                                                        <span
                                                            class="icons icon-magnifier"
                                                        ></span>
                                                        <span class="text"
                                                            >Quick view</span
                                                        >
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="proContent">
                                            <h5 class="proName">
                                                <a
                                                    href="products/turning-table.html"
                                                    >Turning Table</a
                                                >
                                            </h5>
                                            <div class="groupPrice clearfix">
                                                <div class="proPrice">
                                                    <div class="priceProduct">
                                                        <span class="money"
                                                            >$59,00</span
                                                        >
                                                    </div>
                                                </div>
                                                <div
                                                    class="velaSwatchCus"
                                                ></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "TrendingProductContainer"
};
</script>
