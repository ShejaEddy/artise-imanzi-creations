<template>
  <div class="modal-body">
    <slot />
  </div>
</template>