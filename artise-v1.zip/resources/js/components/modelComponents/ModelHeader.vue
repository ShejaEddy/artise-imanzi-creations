<template>
  <div class="modal-header">
    <slot />
  </div>
</template>