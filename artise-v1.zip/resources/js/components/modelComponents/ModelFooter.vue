<template>
  <div class="modal-footer">
    <slot />
  </div>
</template>